package com.example.theater.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.theater.model.Movie;

import com.example.theater.service.MovieService;

@RestController
public class MovieController {
	@Autowired
	MovieService movieservice;

	@PostMapping("/movie/add")	
		public String AddmovieDetails(@RequestBody Movie movie)
		{
		
	  String str=movieservice.AddmovieDetails(movie);
	     return str;

	}

}
