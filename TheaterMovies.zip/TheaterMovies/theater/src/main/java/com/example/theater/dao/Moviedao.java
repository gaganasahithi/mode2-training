package com.example.theater.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.theater.model.Movie;


@Repository
public interface Moviedao extends CrudRepository<Movie,String> {

}
