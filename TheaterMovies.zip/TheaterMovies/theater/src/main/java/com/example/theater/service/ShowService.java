package com.example.theater.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.theater.dao.Showdao;
import com.example.theater.dao.Theaterdao;
import com.example.theater.dto.showdto;
import com.example.theater.dto.theaterdto;
import com.example.theater.model.Show;
import com.example.theater.model.Theater;

@Service
public class ShowService {
	
	@Autowired	
	Showdao showdao;
	@Autowired	
	Theaterdao theaterdao;
	
	
//Adding show Details	
public String AddshowDetails(Show show) 
{
		showdao.save(show);
		return "Successfully registered";
 }

//To check whether the movie exists or not
public String checkmovie(showdto showdto)throws Exception
{
	int count=0;
	List<Show> list =(List<Show> )showdao.findAll();
    for(Show show:list)
{
	if(showdto.getShowtheater().equalsIgnoreCase(show.getMrngshow())||
			showdto.getShowtheater().equalsIgnoreCase(show.getNoonshow())||
			showdto.getShowtheater().equalsIgnoreCase(show.getEvngshow()))
	{

		count=1;
		return "Moive exist";
	}
}
	if(count==0){
	return"the movie you are searching is not available";
}
return null;
}
//fetching list of theater by movie name
public List<theaterdto> findByName(String moviename)
{
	List<Show> listshow=showdao.findByShow(moviename);
	Theater theater2=new Theater();
	List<theaterdto> list=new ArrayList();
	for(Show show1:listshow)
	{
		theaterdto teaterdto=new theaterdto();
		String theater_id=show1.getTheaterId();
		theater2=theaterdao.findById(theater_id).orElse(null);
		teaterdto.setPlace(theater2.getPlace());
		teaterdto.setTheatername(theater2.getTheatername());
		teaterdto.setEvngshow(show1.getEvngshow());
		teaterdto.setMrngsahow(show1.getMrngshow());
		teaterdto.setNoonshow(show1.getNoonshow());
		list.add(teaterdto);
	}
	return list;

	
}
	
}


