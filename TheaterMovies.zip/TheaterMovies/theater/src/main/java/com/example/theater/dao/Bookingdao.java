package com.example.theater.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.theater.model.Booking;


public interface Bookingdao extends CrudRepository<Booking,Integer> {

}
