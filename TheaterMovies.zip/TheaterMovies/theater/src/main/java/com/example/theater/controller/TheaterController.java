package com.example.theater.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.theater.model.Theater;
import com.example.theater.service.TheaterService;

;

@RestController
public class TheaterController {
	
	@Autowired
TheaterService theaterservice;

@PostMapping("/customer/add")	
	public String AddtheaterDetails(@RequestBody Theater theater)
	{
	
  String str=theaterservice.AddtheaterDetails(theater);
     return str;

}

/*@GetMapping("/list/theater")	
public String getAllDetails(String theaterId)
{

String str= theaterservice.moviedetails(theaterId);
return str;

}*/

@GetMapping("/movie/{moviename}")
public List<Theater> getTheater(@PathVariable(value="moviename")String moviename)
{
	return theaterservice.findmovie(moviename) ;
	
}
}


