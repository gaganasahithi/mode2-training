package com.example.theater.dto;

public class theaterdto {
	String theatername;
	String place;
	String mrngsahow;
	String noonshow;
	String evngshow;
	public String getTheatername() {
		return theatername;
	}
	public void setTheatername(String theatername) {
		this.theatername = theatername;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getMrngsahow() {
		return mrngsahow;
	}
	public void setMrngsahow(String mrngsahow) {
		this.mrngsahow = mrngsahow;
	}
	public String getNoonshow() {
		return noonshow;
	}
	public void setNoonshow(String noonshow) {
		this.noonshow = noonshow;
	}
	public String getEvngshow() {
		return evngshow;
	}
	public void setEvngshow(String evngshow) {
		this.evngshow = evngshow;
	}
	
}
