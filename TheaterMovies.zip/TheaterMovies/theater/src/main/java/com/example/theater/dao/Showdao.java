package com.example.theater.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.theater.model.Show;


@Repository
public interface Showdao  extends CrudRepository<Show,String>{
	
@Query(value="select * from shows  s where s.mrngshow=?1 or s.noonshow=?1 or s.evngshow=?1",nativeQuery=true)
List<Show>findByShow(String moviename);

}
