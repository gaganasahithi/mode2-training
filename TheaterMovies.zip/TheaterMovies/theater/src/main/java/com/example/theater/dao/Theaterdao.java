package com.example.theater.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.theater.model.Theater;

@Repository
public interface Theaterdao extends CrudRepository<Theater,String> {

	/*@Query("select t from theater t")
  public   List<Theater>getAllDetails(String theaterId);
	*/
@Query(value="select * from theater t where t.theater_id IN(select s.theater_id from shows s where s.mrngshow=?1 or s.noonshow=?1 or s.evngshow=?1)",nativeQuery=true)
	List<Theater> findByMovie(String moviename);
	
}
