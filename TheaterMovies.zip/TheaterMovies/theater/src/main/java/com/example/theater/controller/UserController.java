package com.example.theater.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.theater.model.User;

import com.example.theater.service.UserService;

@RestController
public class UserController {
	@Autowired
	UserService userservice;

	@PostMapping("/movie/user/add")	
		public String AdduserDetails(@RequestBody User user)
		{
		
	  String str=userservice.AdduserDetails(user);
	     return str;

	}

}
