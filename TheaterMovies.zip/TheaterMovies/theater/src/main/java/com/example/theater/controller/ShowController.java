package com.example.theater.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.theater.dto.showdto;
import com.example.theater.dto.theaterdto;
import com.example.theater.model.Show;

import com.example.theater.service.ShowService;

@RestController
public class ShowController {
	@Autowired
	ShowService showservice;

	@PostMapping("/movie/show/add")	
		public String AddshowDetails(@RequestBody Show show)
		{
		
	  String str=showservice.AddshowDetails(show);
	     return str;

	}
	@PostMapping("/movie/search/movie")	
	public String getShowtheater(@RequestBody showdto showdto) throws Exception
	{
	String str=showservice.checkmovie(showdto);
     return str;

}
	@GetMapping("/movie/search/fetch")	
	public List<theaterdto>showDetails(@RequestParam(value="moviename") String moviename)
	{
		 return showservice.findByName(moviename);
   


}
}
