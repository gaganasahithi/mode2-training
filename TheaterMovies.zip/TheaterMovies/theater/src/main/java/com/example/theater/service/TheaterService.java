package com.example.theater.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.theater.dao.Theaterdao;
import com.example.theater.model.Theater;


@Service
public class TheaterService {

	@Autowired	
	Theaterdao theater1;
	
	
//to add theater details
	public String AddtheaterDetails(Theater theater) {
		theater1.save(theater);
		return "Successfully registered";
		 
	}
	
//List of theaters	
	public List<Theater> findmovie(String moviename)
	{
		return theater1.findByMovie(moviename);
		
	}
}
