package com.example.theater.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.theater.dao.Moviedao;

import com.example.theater.model.Movie;


@Service
public class MovieService 
{
@Autowired	
Moviedao moviedao;


//To add movie details
public String AddmovieDetails(Movie movie) {
	moviedao.save(movie);
	return "Successfully registered";
	 
	
}

}
