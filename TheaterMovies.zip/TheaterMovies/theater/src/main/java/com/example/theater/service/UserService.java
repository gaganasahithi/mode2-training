package com.example.theater.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.theater.dao.Userdao;

import com.example.theater.model.User;
@Service
public class UserService {

	@Autowired	
	Userdao userdao;
	
	

	
//To add user details
public String AdduserDetails(User user) {
		userdao.save(user);
		return "Successfully registered";
	}
}
