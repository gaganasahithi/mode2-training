package com.example.theater.dto;

public class showdto {
	
	
	String showtheater;

	public String getShowtheater() {
		return showtheater;
	}

	public void setShowtheater(String showtheater) {
		this.showtheater = showtheater;
	}
	

}
