package com.example.theater.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="shows")
public class Show {

	LocalDate date;
	String theaterId;
	String mrngshow;
	String noonshow;
	String evngshow;
	@Id
	String showid;
	
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getTheaterId() {
		return theaterId;
	}
	public void setTheaterId(String theaterId) {
		this.theaterId = theaterId;
	}
	public String getMrngshow() {
		return mrngshow;
	}
	public void setMrngshow(String mrngshow) {
		this.mrngshow = mrngshow;
	}
	public String getNoonshow() {
		return noonshow;
	}
	public void setNoonshow(String noonshow) {
		this.noonshow = noonshow;
	}
	public String getEvngshow() {
		return evngshow;
	}
	public void setEvngshow(String evngshow) {
		this.evngshow = evngshow;
	}
	public String getShowid() {
		return showid;
	}
	public void setShowid(String showid) {
		this.showid = showid;
	}
	
	
}
