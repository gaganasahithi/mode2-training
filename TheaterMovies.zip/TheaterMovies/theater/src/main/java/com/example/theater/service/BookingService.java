package com.example.theater.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.theater.dao.Bookingdao;
import com.example.theater.dao.Showdao;
import com.example.theater.dao.Theaterdao;
import com.example.theater.model.Booking;
import com.example.theater.model.Show;
import com.example.theater.model.Theater;
@Service
public class BookingService {
	@Autowired

	Bookingdao bookingdao;

	@Autowired

	Theaterdao theaterdao;

	@Autowired

	Showdao showdao;

	public Booking addBooking(String moviename,String theaterId,String showtime,String userid) {

	Theater theater= theaterdao.findById(theaterId).orElse(null);
	Show show=showdao.findById(theaterId).orElse(null);
	Booking b=new Booking();

	b.setUserid(userid);
	b.setShowtime(showtime);
	b.setMoviename(moviename);
	b.setTheatername(theater.getTheatername());
	b.setDate(LocalDate.now());

	return bookingdao.save(b);

	//return "Successfully entered the Booking details";

	}

}
