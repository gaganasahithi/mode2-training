package com.springmvc.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springmvc.dao.StudentDao;
import com.springmvc.dao.StudentService;
import com.springmvc.dto.AcademicDto;
import com.springmvc.model.Academic;
import com.springmvc.model.Student;
import com.springmvc.service.StudentDetails;

@Controller
public class StudentController {

	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);
	@Autowired
	StudentService studService;
	
	
	

	@RequestMapping(value = "student/add", method = RequestMethod.GET)
	public String addStudent(Model model) {
		model.addAttribute("studadmdto", new AcademicDto());
		logger.info("Returning registration.jsp page");
		return "StudentRegistration";

	}

	@RequestMapping(value = "student/add.do", method = RequestMethod.POST)
	public String saveStudAcdmDetails(@ModelAttribute("studadmdto") AcademicDto studadmdto, BindingResult bindingResult,
			Model model) {
		if (bindingResult.hasErrors()) {
			logger.info("Returning userregn.jsp page");
			return "StudentRegistration";
		}
		ModelMapper mapper = new ModelMapper();
		Student student = mapper.map(studadmdto, Student.class);
		Academic academic = mapper.map(studadmdto, Academic.class);
		model.addAttribute("studadmdto", studadmdto);
		this.studService.addStudent(student, academic);
		logger.info("Returning success_registered.jsp page");
		return "successfulregistration";
	}

	@RequestMapping(value = "student/usn", method = RequestMethod.GET)
	public String searchStudUsn(Model model) {
		model.addAttribute("studadmdto", new AcademicDto());
		logger.info("Returning studentusn.jsp page");

		return "usn";

	}

	@RequestMapping(value = "student/usn/find.do", method = RequestMethod.POST)
	public String getStudPlace(@ModelAttribute("studadmdto") AcademicDto studadmdto, BindingResult bindingResult,
			Model model) {
		if (bindingResult.hasErrors()) {
			logger.info("Returning studentusn.jsp page");
			return "usn";
		}
		ModelMapper mapper = new ModelMapper();
		Student student = mapper.map(studadmdto, Student.class);
		System.out.println(studadmdto.toString());

		model.addAttribute("studadmdto", studadmdto);
		/*
		 * String usn1 = student.getUsn(); model.addAttribute("usn1", usn1);
		 */
		/*
		 * String place = this.studService.getDetails(student.getUsn());
		 * model.addAttribute("place", place);
		 */

		logger.info("Returning success_placeOf Stud.jsp page");

		return "successfulregistrationusn";
	}

	@RequestMapping(value = "/student/getstudents", method = RequestMethod.GET)
	public String getlink(@ModelAttribute("student") Student student, BindingResult bindingResult, Model model) {
		logger.info("Returning link.jsp page");
		return "link";
	}

	@RequestMapping(value = "view/{pageid}")
	public String getAllStudentDetails(@PathVariable int pageid, Model model) {
		System.out.println("in page controller");
		System.out.println("=========" + pageid);
		int total = 3;
		if (pageid == 1) {
		} else {
			pageid = (pageid - 1) * total + 1;
		}
		List<Student> list = studService.getAllStudents(pageid, total);
		model.addAttribute("msg", list);
		return "StudentDetailsjsp";

	}

	@RequestMapping(value = "student/post/{usn}")
	@ResponseBody
	public String display(@PathVariable String usn) {
		return studService.getDetails(usn);

	}
	
	@RequestMapping(value = "student/getlist")
	@ResponseBody
	public List<Student>listStudent()
	{
		return studService.listStudent();
}
}
