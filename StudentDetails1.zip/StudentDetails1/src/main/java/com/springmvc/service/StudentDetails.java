package com.springmvc.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springmvc.dao.StudentDao;
import com.springmvc.model.Academic;
import com.springmvc.model.College;
import com.springmvc.model.Student;

@Repository("studDAO")
public class StudentDetails implements StudentDao {

	@Autowired
	SessionFactory sessionFactory;

	private static final Logger logger = LoggerFactory.getLogger(StudentDao.class);

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public StudentDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Autowired
	public StudentDetails(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	ModelMapper mapper = new ModelMapper();

	@Override
	public void addStudent(Student student, Academic academic) {
		Session session = this.sessionFactory.getCurrentSession();

		logger.info("Saving details from registration.jsp form to db of Student and Academic table");
		session.save(student);
		session.save(academic);
	}
	@Transactional
	@Override
	public String getDetails(String usn) {
		System.out.println(usn);
	      String code1 = usn.substring(1, 3);
		Query query = sessionFactory.getCurrentSession().createQuery("from College where code= :code");
		query.setParameter("code", code1);
		List<College> listCol = query.list();
		Iterator<College> itr = listCol.iterator();
		String place1 = null;
		while (itr.hasNext()) {
			College college = (College) itr.next();
			place1 = college.getPlace();
		}
		logger.info("Using usn from studentusn.jsp finding the place of student");
		return place1;
	}

	@Transactional
	@Override
	public List<Student> getAllStudents(int pageid, int total) {
		System.out.println("----" + "in details method");
		String sql = "from Student";
		Query query = sessionFactory.getCurrentSession().createQuery(sql);
		query.setFirstResult(pageid - 1);
		query.setMaxResults(total);
		// List<Student> stddet = new ArrayList<Student>();
		List<Student> studlist = query.list();
		System.out.println("Displaying pagination contents");
		for (int i = 0; i < studlist.size(); i++) {
			System.out.println("-------" + studlist.get(i).getName());
		}
		return studlist;

	}
	@Transactional
	@Override
	public List<Student>listStudent()
	{
		Session session=sessionFactory.getCurrentSession();
		Criteria c= session.createCriteria(Student.class);
		List<Student> list=c.list();
		return list;
	} 

}
