package com.springmvc.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springmvc.dao.StudentDao;
import com.springmvc.dao.StudentService;
import com.springmvc.model.Academic;
import com.springmvc.model.Student;



@Service
public class StudentService1 implements StudentService
{
	@Autowired
	StudentDao studDAO;
	
	public void setStudDAO(StudentDao studDAO) {
		this.studDAO = studDAO;
	}
//This method is used to add the Students	
	@Transactional
	@Override
	public void addStudent(Student student, Academic academic) {
		studDAO.addStudent(student, academic);
		
	}

//fetching  the details of students by using usn number
	@Transactional
	@Override
	public String getDetails(String usn1)
	{
	return	studDAO.getDetails(usn1);
		
	
	}


	@Transactional
	@Override
	public List<Student> getAllStudents(int pageid, int total) {
	
		return studDAO.getAllStudents(pageid, total);
	}
	//List of Students
	@Transactional
	@Override
public List<Student>listStudent()
{
	return studDAO.listStudent();
}
}


