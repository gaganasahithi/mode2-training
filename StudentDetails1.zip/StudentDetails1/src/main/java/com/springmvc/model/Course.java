package com.springmvc.model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;


public class Course implements Serializable {

	
	private String collegeCode;
	
	
	private String course;


	public String getCollegeCode() {
		return collegeCode;
	}


	public void setCollegeCode(String collegeCode) {
		this.collegeCode = collegeCode;
	}


	public String getCourse() {
		return course;
	}


	public void setCourse(String course) {
		this.course = course;
	}
}
