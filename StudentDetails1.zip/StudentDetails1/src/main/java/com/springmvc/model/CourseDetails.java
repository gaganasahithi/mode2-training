package com.springmvc.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class CourseDetails {

	@EmbeddedId
	private Course course1;

	public Course getCourse1() {
		return course1;
	}

	public void setCourse1(Course course1) {
		this.course1 = course1;
	}
}
