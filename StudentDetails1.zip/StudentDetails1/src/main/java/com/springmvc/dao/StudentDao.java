package com.springmvc.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.springmvc.model.Academic;
import com.springmvc.model.Student;



public interface StudentDao {
	public void addStudent(Student student, Academic academic);
	public String getDetails(String usn);
	public  List<Student> getAllStudents(int pageid, int total);
public	List<Student> listStudent();

}
