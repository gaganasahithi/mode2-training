package com.springmvc.dao;

import java.util.List;

import com.springmvc.model.Academic;
import com.springmvc.model.Student;

public interface StudentService {
	public void addStudent(Student student, Academic acadmic);
	public String getDetails(String usn);
	public  List<Student> getAllStudents(int pageid, int total);
	public List<Student> listStudent();
}
