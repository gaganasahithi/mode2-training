package com.demo.studentdb.service;



import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.studentdb.Dao.StudentDao;
import com.demo.studentdb.dto.StudentDto;
import com.demo.studentdb.dto.StudentGetDto;
import com.demo.studentdb.entity.Student;
import com.demo.studentdb.exception.StudentNotFoundException;

@Service
public class StudentService {

	@Autowired
	StudentDao studentDao;
	
	ModelMapper mapper = new ModelMapper();
//To get Student Details	
	public StudentGetDto getStudentDetails(Integer studentId) {
		Student student = studentDao.findById(studentId).orElse(null);
		if(student == null) {
			throw new StudentNotFoundException("id-" + studentId);
		}
		StudentGetDto studentGetDto = mapper.map(student, StudentGetDto.class);
		return studentGetDto;
	}
//To add Students
	public void addStudent(StudentDto studentDto) {
		Student student = mapper.map(studentDto, Student.class);
		studentDao.save(student);
	}

}
