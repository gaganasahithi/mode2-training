
    package com.pack.annotations;
	import java.lang.annotation.Repeatable;
	import java.lang.annotation.Retention;
	import java.lang.annotation.RetentionPolicy;
	import java.util.ArrayList;
	import java.util.List;
	import java.util.Scanner;

	
	@Repeatable(MyAnnotation1.class)
	@interface MyAnnotation
	{
		String name();
		int age();
		long phoneNo();
		String accNo();
	}
	@Retention(RetentionPolicy.RUNTIME)
	@interface MyAnnotation1
	{
		MyAnnotation[] value();
	}
	@MyAnnotation(age=20, name = "Sahithi",phoneNo=1234567890,accNo="2500000")
	@MyAnnotation(age=21, name = "Sai",phoneNo=1334567890,accNo="1000000")
	@MyAnnotation(age=22, name = "Sahi",phoneNo=1236987410,accNo="2000000")
	@MyAnnotation(age=23, name = "Honey",phoneNo=2134567890,accNo="2100000")
	@MyAnnotation(age=24, name = "Swetha",phoneNo=1834567890,accNo="1100000")
	@MyAnnotation(age=25, name = "Gagana",phoneNo=1934567890,accNo="1200000")
	@MyAnnotation(age=26, name = "Raji",phoneNo=1634567890,accNo="1400000")
	@MyAnnotation(age=27, name = "Viswa",phoneNo=1534567890,accNo="1500000")
	@MyAnnotation(age=28, name = "Ajay",phoneNo=1434567890,accNo="1600000")
	@MyAnnotation(age=29, name = "Rahul",phoneNo=1234567892,accNo="1800000")
	
	public class Customer {
		

		String name;

		int age;
		Long phoneNo;
		String accNo;
	
		float balance;
		List<String> mini=new ArrayList<String>();
	
		
		
		public Customer(String name, int age, Long phoneNo,String accNo,float balance) {
			super();
			this.name = name;
			this.age = age;
			this.phoneNo = phoneNo;
			this.accNo=accNo;
			this.balance=balance;
		
			
	}

		public Customer() {
			
		}

		
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}

		public Long getPhoneNo() {
			return phoneNo;
		}

		public void setPhoneNo(Long phoneNo) {
			this.phoneNo = phoneNo;
		}

		public String getAccNo() {
			return accNo;
		}

		public void setAccNo(String accNo) {
			this.accNo = accNo;
		}
		//To withdraw the amount
		public void withdraw(List<Customer> l5,int flag){
			System.out.println("Enter the amount to be withdraw");
			Scanner s=new Scanner(System.in);
			float amount=s.nextFloat();
			if(l5.get(flag).balance<amount){
				System.out.println("Your balance is Less!!!!");
			}
			else{
				balance=l5.get(flag).balance-amount;
				l5.get(flag).balance=balance;
				String s1="Withdrawn" + amount;
				l5.get(flag).mini.add(s1);
			}
			}
		//To deposit the amount
			public void deposit(List<Customer> l5,int flag){
				System.out.println("Enter the amount to be deposited");
				Scanner s=new Scanner(System.in);
				float deposit=s.nextFloat();
				balance=l5.get(flag).balance+deposit;
				l5.get(flag).balance=balance;
					String s2="deposited:" +deposit;
					l5.get(flag).mini.add(s2);
				}
			int k=1;
			//To display the transcations
			public void display(List<Customer> l5,int flag){
				
				System.out.println("**********Your Transactions************");
				System.out.println("Name:"+l5.get(flag).name+"age:"+l5.get(flag).age+"phoneNo"+l5.get(flag).phoneNo);
				System.out.println("Available balance is:"+l5.get(flag).balance);
				
				for(int i=l5.get(flag).mini.size()-1;i>=0;i--){
					System.out.println(k+". "+l5.get(flag).mini.get(i));
					System.out.println();
					k++;
					if(k==11){
						break;
					}

	}
			}
	}


