package com.pack.annotations;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class MathOperations {

	public static void main(String[] args) {
			
		MyAnnotation[]  a= MathOperations.class.getAnnotationsByType(MyAnnotation.class);
for(MyAnnotation  MyAnnotation: a)
{
	System.out.println(MyAnnotation.name()+" "+MyAnnotation.age());
}
	
	
		List<Integer> l1 = new ArrayList<Integer>();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		for (int i = 0; i < 10; i++) {
			int y = sc.nextInt();
			l1.add(y);
		}
		Customer[] c = new Customer[15];
		List<String> l2 = l1.stream().map(x -> "SBI" + x).collect(Collectors.toList());
		System.out.println("Total account numbers are" + l2);
		List<String> l3 = l2.stream().filter(i -> i.length() == 8).collect(Collectors.toList());
		System.out.println("Valid accounts are" + l3);
		List<String> l4 = l2.stream().filter(i -> i.length() != 8).collect(Collectors.toList());
		System.out.println("InValid accounts are" + l4);
		List<Customer> customer = new ArrayList<Customer>();
		String nameList;
		int ageList;
		Long phonenoList;
		String accNo = null;
		float amount;
		float balance;
		for (int i = 0; i < l3.size(); i++) {
			nameList = sc.next();
			ageList = sc.nextInt();
			phonenoList = sc.nextLong();
			balance = sc.nextFloat();
			accNo = l3.get(i);
			Customer x = new Customer();
			c[i] = new Customer(nameList, ageList, phonenoList,accNo,balance);
			customer.add(c[i]);

		}
		List<Customer> l5 = customer.stream()
.filter(x -> (x.name.matches("[A-Z][a-z].*")) && (x.age >= 18)
&& (String.valueOf(x.phoneNo).matches("[0-9].*") && (String.valueOf(x.phoneNo).length() == 10)))
				.collect(Collectors.toList());
		List<Customer> sortedList = l5.stream().sorted(Comparator.comparing(Customer::getName))
				.collect(Collectors.toList());
		sortedList.forEach((temp) -> {
			System.out.println(temp.accNo + "is valid");
			System.out.println(temp.name + " " + temp.age + " " + temp.phoneNo + " " + temp.accNo + " " + temp.balance);
		});
		List<Customer> l6 = customer.stream().filter(x -> !((x.name.matches("[A-Z][a-z].*")) && (x.age >= 18)
				&& (String.valueOf(x.phoneNo).matches("[0-9].*") && (String.valueOf(x.phoneNo).length() == 10))))
				.collect(Collectors.toList());
		l6.forEach((tem) -> {
			System.out.println(tem.accNo + "is invalid");
			System.out.println(tem.name + " " + tem.age + " " + tem.phoneNo + " " + tem.accNo);
		});
		int ch=0;
		int flag=-1;
		System.out.println("Enter user name");
		String CustomerName=sc.next();
		for(int i=0;i<l5.size();i++){
			if(!(l5.get(i).name.equals(CustomerName))){
				flag=-1;
			}
			else{
				flag=i;
				break;
			}
		}
		if(flag==-1){
			System.out.println("Invalid User..!!!!");
		}
			Customer cust=new Customer();
			
			do{
				System.out.println("Enter the choice");
				System.out.println("1.Withdraw");
				System.out.println("2.deposit");
				System.out.println("3.MiniStatement");
				System.out.println("4.Exit");
				ch=sc.nextInt();
				switch(ch){
				case 1:
					cust.withdraw(l5,flag);
					break;
				case 2:
					cust.deposit(l5,flag);
					break;
				case 3:
					cust.display(l5,flag);
					break;
				case 4:
					System.out.println("Welcome!!...visit us again...!!!!");
					break;
				default:
					System.out.println("User you enetered is not valid");
			}
			}
				while(!(ch==4));
	}

}
