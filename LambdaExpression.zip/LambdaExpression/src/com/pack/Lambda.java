package com.pack;
public interface Lambda {
	/*public void move();*/
	public   void add(int a);


}
