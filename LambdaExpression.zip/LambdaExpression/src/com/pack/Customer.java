package com.pack;
public class Customer {
String phonenumber;
String name;
int age;
String accountno;
int balance;
	public Customer() {
		super();
		
	}
	public Customer(String phonenumber, String name, int age,String accountno,int balance) {
		super();
		this.phonenumber = phonenumber;
		this.name = name;
		this.age = age;
		this.accountno=accountno;
		this.balance=balance;
	}
	
	
	

}
