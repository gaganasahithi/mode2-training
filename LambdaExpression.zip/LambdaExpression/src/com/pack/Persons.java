package com.pack;
public class Persons {

int age;
String name;
public Persons() {
	super();
	
}
public Persons(int age, String name) {
	super();
	this.age = age;
	this.name = name;
}
}
