package com.pack;
public interface Lambda1 {
	public void sub(int a, int b);
}
