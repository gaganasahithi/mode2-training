package com.pack;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main1 {

	public static void main(String[] args) {
	
		
		
Scanner sc= new Scanner(System.in);
List<String> ls=new ArrayList<String>();
for(int i=0;i<10;i++)
{
ls.add(sc.nextLine());
}
Customer c5=new Customer();
	List<String> valid=ls.stream().map(x->"SBI"+x).collect(Collectors.toList());
	System.out.println(valid);
	List<String>validaccount=valid.stream().filter(i->i.length()==8).collect(Collectors.toList());
	System.out.println("valid accounts are");
	System.out.println(validaccount);
	List<String>Invalidaccount=valid.stream().filter(i->i.length()!=8).collect(Collectors.toList());
	System.out.println("Invalid accounts are");
	System.out.println(Invalidaccount);
	Customer c1= new Customer("9134345659","Sahithi",21,null,123454);
	Customer c2= new Customer("1894345656","sai",13,null,122354);
	Customer c3= new Customer("9173425656","Sahi1",22,null,123467);
	Customer c4= new Customer("1258239656","honey",19,null,123565);
	List<Customer> list=new ArrayList<Customer>();
	list.add(c1);
	list.add(c2);
	list.add(c3);
	list.add(c4);
	
	List<Customer> l1=list.stream().filter(l->l.name.matches("^[A-Z].*$")).collect(Collectors.toList());
	List<Customer> l2=l1.stream().filter(k->k.phonenumber.matches("(0/91)?[7-9][0-9]{9}")).collect(Collectors.toList());
	List<Customer> l3=l2.stream().filter(j->(j.age)>18).collect(Collectors.toList());
	//List<Customer>l4=l3.stream().sorted(name: name.split(" ")[-1].lower()).collect(Collectors.toList());
	System.out.println(validaccount.size());
	for(int i1=0;i1<validaccount.size();i1++)
	{
		//System.out.println(validaccount.get(i1));
	
		l3.get(i1).accountno=validaccount.get(i1);
	}
	Iterator it=l3.iterator();
	while(it.hasNext())
	{
		Customer c6=(Customer) it.next();
		System.out.println(c6.name);
		System.out.println(c6.phonenumber);
		System.out.println(c6.age);
		System.out.println(c6.accountno);
	}
	
	
   
	
	
	}
	
	}





