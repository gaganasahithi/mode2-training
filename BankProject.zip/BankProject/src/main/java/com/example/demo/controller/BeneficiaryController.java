package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Beneficiary;

import com.example.demo.service.BeneficiaryService;


@RestController
public class BeneficiaryController {
	
	@Autowired
  BeneficiaryService beneficiaryservice;
	
	@PostMapping("/beneficiary/add")
	public void findallbyid(@RequestBody   Beneficiary beneficiary )
	
	{
		beneficiaryservice.add_customerdetails(beneficiary);
		
}
	@GetMapping("/beneficiary/get/{ifsc}")
	public Beneficiary findByIfsccode(@PathVariable String ifsc )
	
	{
	return beneficiaryservice.findByIfsccode(ifsc);
}
	@RequestMapping(value = "/beneficiary/get/{ifsc}/{baccno}", method = RequestMethod.GET)
	public Beneficiary findByifscAndBaccno(@PathVariable String ifsc,@PathVariable String baccno )
	
	{
	return beneficiaryservice.findByifscAndBaccno(ifsc, baccno);
}
}
