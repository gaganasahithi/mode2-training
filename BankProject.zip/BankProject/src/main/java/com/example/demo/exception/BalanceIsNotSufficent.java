package com.example.demo.exception;

public class BalanceIsNotSufficent extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public BalanceIsNotSufficent(String exception) {
		super(exception);
		// TODO Auto-generated constructor stub
	}

}


