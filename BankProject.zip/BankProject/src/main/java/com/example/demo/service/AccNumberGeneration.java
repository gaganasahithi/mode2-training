package com.example.demo.service;
public class AccNumberGeneration{
	
	//To generate the customerId
	public Integer cust_Id()
	{
		int x=1000;
		
		
				return x++;
	}
}
	
