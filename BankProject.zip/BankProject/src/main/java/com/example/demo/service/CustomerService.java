    package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


import com.example.demo.dao.AccountDao;
import com.example.demo.dao.CustomerDao;
import com.example.demo.exception.AccountNotFoundException;
import com.example.demo.model.Account;
import com.example.demo.model.Customer;

@Service
public class CustomerService {
	@Autowired
	CustomerDao customerDao;
	@Autowired
	AccountDao accountdao;
	Account account=new Account();
	 static int cust_id1= 1000;   
	 long accountno=2000;
	long balance=7000;
	
	//Adding customer details and generating the password and accountno
	public String AddCustomerDetails(Customer customer)
	{
		if(customer.getAge()>21)
		{
			
			customer.setPassword(customer.getPhoneno());
			
			customer.setCustId(cust_id1++);
	      customerDao.save(customer);
	      account.setAccountno("SBI"+accountno++);
	      account.setBalance(balance);
	      account.setCust_id(cust_id1);
	    accountdao.save(account);   			
	      return "Successfully Registered";
			}
		else
		{
			return "check your age,password,accno";
		}
	}
	//Fetching all the customers
	public List<Customer> getAllcustomer()
	{
		List<Customer> customer= new ArrayList();
		
	 customerDao.findAll().forEach(customer::add);
	// customerDao.findAll().forEach(List-> convertToDTo( customer));
	 return customer;

	}
	public void delete(Integer cust_Id) {
		Customer customer= customerDao.findById(cust_Id).orElse(null);
		
		
		if(customer == null) 
		{
			throw new AccountNotFoundException("account not found");
		}	
		customerDao.deleteById(cust_Id);
	}
	//Updating the customerId and Email
	public String  update(Integer cust_Id,String email )
	
	{
		Customer customer=customerDao.findById(cust_Id).orElse(null);
		if(null!=customer)
		{
			customer.setEmail(email);
		}
		customerDao.save(customer);
		return"successfully updated";
	}
	//For pagination 
	public List<Customer> getAllEmployees1(Integer pageNo, Integer pageSize, String sortBy) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));

		Page<Customer> pagedResult = customerDao.findAll(paging);

		if (pagedResult.hasContent()) { 
			return pagedResult.getContent();
		} else {
			return new ArrayList<Customer>();
		}
	
}
}
