package com.example.demo.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Beneficiary;

@Repository
public interface Benificiarydao extends CrudRepository<Beneficiary, String> {
	Beneficiary findByifsc(String ifsc);
	Beneficiary findByifscAndBaccno(String ifsc,String baccno);

}
