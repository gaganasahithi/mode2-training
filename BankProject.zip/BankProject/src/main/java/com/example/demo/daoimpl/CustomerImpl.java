package com.example.demo.daoimpl;

public class CustomerImpl {
}
