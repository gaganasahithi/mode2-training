package com.example.demo.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;


import com.example.demo.model.Transcation;

public interface TranscationDao
		extends CrudRepository<Transcation, Integer>, PagingAndSortingRepository<Transcation, Integer> {

}
