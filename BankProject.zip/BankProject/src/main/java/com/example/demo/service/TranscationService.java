package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.dao.AccountDao;
import com.example.demo.dao.TranscationDao;
import com.example.demo.exception.AccountNotFoundException;
import com.example.demo.model.Account;

import com.example.demo.model.Transcation;

@Service
public class TranscationService {
	@Autowired
	TranscationDao tranDao;
	@Autowired
	AccountDao accountdao;
	Account account = new Account();
	Transcation transcation = new Transcation();
//Checking the balance 
	public void checkbalance() {
		if (account.getBalance() < transcation.getAmount())

		{
			System.out.println("amount is insufficent");
		} else {
			System.out.println("balance is sufficent");
		}
	}
//For Debit
	public String debit(Transcation transcation2) {

		Account account = accountdao.findById(transcation2.getCust_id()).orElse(null);
		long balance = account.getBalance();
		if (transcation2.getAmount() <= balance) {
			balance -= transcation2.getAmount();
			// transcation2.setCust_id(account.getCust_id());
			transcation2.setTransactiontype("debit");
			transcation2.setDescription("debited from:" + account.getAccountno());
			transcation2.setAccountno(account.getAccountno());
			account.setBalance(balance);
			System.out.println(account.getBalance());
			tranDao.save(transcation2);

			System.out.println(transcation2);
			accountdao.save(account);
			System.out.println("debit");
			return "debited";
		} else {
			throw new AccountNotFoundException("balance is not sufficent");
		}
	}
//For credit
	public String credit(Transcation transactions, Integer cust_id) {
		System.out.println("inside credit method");
		List<Account> accList = (List<Account>) accountdao.findAll();
		List<Account> account1 = accList.stream().filter(x -> x.getCust_id().equals(cust_id))
				.collect(Collectors.toList());
		long balance1 = account1.get(0).getBalance();
		int i = cust_id;
		int j = account1.get(0).getCust_id();
		// getAccountno().equals(accNo)
		if (i != j) {
			if (transactions.getAmount() <= balance1) {
				System.out.println("other account");
				debit(transactions);
				balance1 += transactions.getAmount();
				Transcation transactions1 = new Transcation();
				transactions1.setTransactiontype("credit");
				transactions1.setCust_id(account1.get(0).getCust_id());
				transactions1.setAccountno(account1.get(0).getAccountno());
				transactions1.setDescription("credited to :" + account1.get(0).getAccountno());
				transactions1.setAmount(transactions.getAmount());
				account1.get(0).setBalance(balance1);
				tranDao.save(transactions1);
				accountdao.save(account1.get(0));
				return "credited";
			} else {
				return "No sufficient balance";
			}
		} else {
			balance1 += transactions.getAmount();
			Transcation transcation1 = new Transcation();
			transcation1.setTransactiontype("credit");
			transcation1.setCust_id(account1.get(0).getCust_id());
			transcation1.setAccountno(account1.get(0).getAccountno());
			transcation1.setDescription("credited to :" + account1.get(0).getAccountno());
			transcation1.setAmount(transcation.getAmount());
			account1.get(0).setBalance(balance1);
			tranDao.save(transcation1);
			accountdao.save(account1.get(0));
			System.out.println("credited");
			return "credited";
		}
	}
//To get the list of transcation
	public List<Transcation> getAllEmployees(Integer pageNo, Integer pageSize, String sortBy) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));

		Page<Transcation> pagedResult = tranDao.findAll(paging);

		if (pagedResult.hasContent()) {
			return pagedResult.getContent();
		} else {
			return new ArrayList<Transcation>();
		}
	}

}
