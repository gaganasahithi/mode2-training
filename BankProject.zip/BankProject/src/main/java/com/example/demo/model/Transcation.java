package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="transcation")
public class Transcation {

long amount;
String description;
@Id	
 @GeneratedValue(strategy=GenerationType.AUTO) 
Integer cust_id;
String accountno;
String transactiontype;


public long getAmount() {
	return amount;
}
public void setAmount(long amount) {
	this.amount = amount;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public Integer getCust_id() {
	return cust_id;
}
public void setCust_id(Integer cust_id) {
	this.cust_id = cust_id;
}
public String getAccountno() {
	return accountno;
}
public void setAccountno(String accountno) {
	this.accountno = accountno;
}
public String getTransactiontype() {
	return transactiontype;
}
public void setTransactiontype(String transactiontype) {
	this.transactiontype = transactiontype;
}




}
