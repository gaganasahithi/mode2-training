package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customer;

import com.example.demo.service.CustomerService;


@RestController

public class HomeController {

	

	@Autowired
CustomerService custservice;

@PostMapping("/customer/add")	
	public String AddCustomerDetails(@RequestBody Customer customer)
	{
	
  String str=custservice.AddCustomerDetails(customer);
return str;
	
	}
   @GetMapping("/customer/all")
	public List<Customer> getAllcustomer()
	{
	 return custservice.getAllcustomer();
	}

@PostMapping("/customer/delete/{cust_Id}")
public  void delete(@PathVariable Integer cust_Id)
{
	System.out.println(cust_Id);
	custservice.delete(cust_Id);
}
@PostMapping("/customer/update")
public String update(@PathVariable Integer cust_Id,@RequestBody String email)
	
{
	return custservice.update(cust_Id, email);
}
@RequestMapping("customer/getage")
@GetMapping
public ResponseEntity<List<Customer>> getAllEmployees(
		@RequestParam(defaultValue = "0") Integer pageNo,
		@RequestParam(defaultValue = "10") Integer pageSize,
		@RequestParam(defaultValue = "age") String sortBy) {
	List<Customer> list = custservice.getAllEmployees1(pageNo, pageSize, sortBy);

	return new ResponseEntity<List<Customer>>(list, new HttpHeaders(), HttpStatus.OK);
}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

