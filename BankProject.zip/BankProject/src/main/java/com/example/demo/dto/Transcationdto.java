package com.example.demo.dto;

public class Transcationdto {
String	fromaccountno;
String  toaccountno;
	
	

}
