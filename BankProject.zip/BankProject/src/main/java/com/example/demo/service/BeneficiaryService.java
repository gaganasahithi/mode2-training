package com.example.demo.service;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.Benificiarydao;
import com.example.demo.model.Beneficiary;


@Service
public class BeneficiaryService {
	@Autowired
	Benificiarydao beneficiarydao;
//To add Customer details
	public String add_customerdetails(Beneficiary beneficiary) {
		beneficiary.setCust_id(beneficiary.getCust_id());
		beneficiary.setBaccno(beneficiary.getBaccno());
		beneficiary.setIfsc(beneficiary.getIfsc());
		beneficiarydao.save(beneficiary);
		return "successfull";
	}
//fetching the customer  details by Ifsc code
	public Beneficiary findByIfsccode(String ifsc) 
	{
		return beneficiarydao.findByifsc(ifsc);
	}
//	fetching the customer details by using ifsc code and bankaccountno
	public Beneficiary findByifscAndBaccno(String ifsc,String baccno)
	{
		return beneficiarydao.findByifscAndBaccno(ifsc, baccno);
	}
	 
}